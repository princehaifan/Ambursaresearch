---
name: paper-writer
description: >
  Step 4 of 6 in the ambursaResearch Pipeline. Writes each section of the
  paper to journal standard: Abstract, Introduction, Methods, Results,
  Discussion, Conclusion. Provides section-specific templates, sentence-level
  guidance, and common failure modes for each part. Produces a complete draft
  ready for expert revision. Saves as draft_sections.md.
---

# Paper Writer

You have a validated topic, a mapped literature, and a rigorous method.
Now you write.
Most researchers stall here not because they cannot write,
but because they try to write perfectly on the first pass.
The first draft has one job: exist.
It does not need to be good.
It needs to be complete.
You cannot revise a blank page.
Write the full draft first. Revise second.
This skill gives you a structure for every section,
sentence starters for every paragraph,
and the specific failure modes to avoid in each part.
Save as `draft_sections.md`.

---

## Prerequisites

```
READ FIRST: topic_brief.md    → research question, gap statement
READ SECOND: literature_map.md → core set, introduction architecture
READ THIRD: study_design.md   → design, PICO, analysis plan, methods draft
```

---

## The Writing Order

```
DO NOT WRITE IN READING ORDER.
Write in the order that unlocks the next section.

RECOMMENDED ORDER:
  1. Methods (already drafted in step 3 — refine here)
  2. Results (describe what your analysis found)
  3. Discussion (interpret results against the literature)
  4. Introduction (now you know what your paper actually argues)
  5. Abstract (once the paper exists, summarise it)
  6. Title (last — it names what the paper actually is)

RULE: Writing introduction first is the most common mistake.
You write an introduction for a paper you imagined.
Then the results show you something different.
Now your introduction promises something you did not deliver.
Write introduction after results and discussion.
```

---

## Section 1 — Abstract

```
THE ABSTRACT IS THE MOST READ SECTION. WRITE IT LAST.

STRUCTURED ABSTRACT FORMAT (most journals):
  Background:    1–2 sentences. The problem and the gap.
  Objective:     1 sentence. What this paper does.
  Methods:       2–3 sentences. Design, population, analysis.
  Results:       2–4 sentences. Main findings (numbers).
  Conclusions:   1–2 sentences. What this means.
  Keywords:      5–8 terms. Use MeSH terms where applicable.

RULES FOR ABSTRACTS:
  → Every number in the abstract must appear in the results.
  → Every claim must be supported by the paper.
  → No citations in the abstract.
  → No jargon without definition (the abstract is read by people
    outside your specialty).
  → "We found that X was significantly associated with Y (OR 2.1,
    95% CI 1.4–3.1, p<0.001)" — always give effect sizes, not just p-values.

ABSTRACT FAILURE MODES:
  × "We discuss the implications..." — do not preview. State the finding.
  × "Results showed significant differences." — which differences? Give numbers.
  × "Our study has several limitations." — say the main one, not all of them.
```

---

## Section 2 — Introduction

```
USE THE ARCHITECTURE FROM literature_map.md.

FOUR PARAGRAPHS. MAX 600 WORDS.

PARAGRAPH 1 — The Field (opening hook):
  Start with the problem, not the history.
  × "Since the discovery of X in 1972..."
  ✓ "X affects 400 million people globally and remains one of the most
     under-researched risk factors for [outcome]."
  Establish the scale and relevance in the first three sentences.

PARAGRAPH 2 — The Debate:
  What do we know, and where is the evidence inconsistent?
  "While [finding A] has been established by [citation], evidence for
   [related finding] is mixed. [Citation] found X, while [citation] found Y.
   This inconsistency may be explained by [reason], but this has not
   been tested directly."

PARAGRAPH 3 — The Gap:
  State your gap statement.
  Cite the gap papers.
  "To our knowledge, no study has examined [gap] in [population/context]."
  "Previous reviews have called for [your study type] to address [gap]."

PARAGRAPH 4 — This Paper:
  "In this [study type], we [verb: examine/test/analyse/report] [outcome]
   among [population] using [data/method].
   We hypothesise that [hypothesis].
   These findings will [contribute to / address / resolve] [gap]."

INTRODUCTION FAILURE MODES:
  × Too long. If your introduction is >800 words: cut.
  × Starting with a definition. ("Depression is a mental illness that...")
  × Citing too few papers. Minimum 15 citations in the introduction.
  × Overclaiming novelty. ("No research exists on this topic.")
    — Reviewers know the literature. They will find the paper you missed.
  × Underclaiming significance. The reader should finish paragraph 3
    thinking: "Someone really needed to do this study."
```

---

## Section 3 — Methods (Refine from study_design.md)

```
USE THE DRAFT FROM study_design.md.
REFINE IT FOR THE TARGET JOURNAL.

JOURNAL FORMATTING RULES:
  → Check the journal's author guidelines for section structure.
  → Some journals want 2.1, 2.2, 2.3 subsections.
  → Some journals want a single Methods paragraph.
  → Adapt the draft accordingly.

THE REPLICABILITY CHECK:
  Read your methods section aloud.
  Ask: could a researcher in a different city replicate this study
  exactly, using only what I have written?
  If the answer is no: what is missing?
  Add it.

ETHICS STATEMENT (required by most journals):
  "This study was approved by [institution] ethics committee
  (reference number [X]). Informed consent was obtained from all participants."
  OR:
  "Ethics approval was not required for this study because [reason —
  e.g., secondary analysis of anonymised public data]."
```

---

## Section 4 — Results

```
RESULTS REPORT. RESULTS DO NOT INTERPRET.
SAVE INTERPRETATION FOR THE DISCUSSION.

STRUCTURE:

  4.1 SAMPLE DESCRIPTION (Table 1 — almost every paper has one)
  Describe your sample before your findings.
  Demographics, key characteristics.
  "Table 1 shows the characteristics of the study sample (N = [X]).
   The mean age was [X] (SD [X]). [X]% were female.
   [Other key characteristics]."

  4.2 PRIMARY RESULTS
  State the main finding first. Numbers always.
  "In the primary analysis, [exposure] was associated with
   [outcome] (OR 2.1, 95% CI 1.4–3.1, p<0.001)."

  4.3 SECONDARY RESULTS
  Subgroup analyses, secondary outcomes.
  One paragraph per secondary finding.

  4.4 SENSITIVITY ANALYSES (if applicable)
  "Results were robust in sensitivity analyses excluding [X]."

RESULTS FAILURE MODES:
  × Interpreting in the results. "Surprisingly, X was associated with Y" —
    remove "surprisingly". That belongs in the discussion.
  × Missing effect sizes. Never report p-value alone.
  × Missing confidence intervals. Every estimate needs a CI.
  × Inconsistent numbers. Check every number in results against your
    analysis output. ONE inconsistency = desk reject.
  × Tables without titles. Every table and figure needs a standalone title
    and legend. A reader should understand a table without reading the text.
```

---

## Section 5 — Discussion

```
THE DISCUSSION IS WHERE YOU BECOME A SCHOLAR.
IT IS ALSO WHERE MOST PAPERS FAIL.

FIVE-PART DISCUSSION STRUCTURE:

  PART 1 — MAIN FINDING (1 paragraph)
  "The main finding of this study is that [restate your primary result
   in one sentence, without statistics]."
  Do not start with "In this study, we found..."
  Start with what you found: "X was associated with Y, even after
  adjusting for [confounders]."

  PART 2 — COMPARISON WITH PRIOR LITERATURE (2–3 paragraphs)
  How do your findings compare with your direct comparators?
  "Consistent with [citation], we found..."
  "In contrast to [citation], our findings suggest..."
  For every inconsistency with prior literature: offer a reason.
  "This discrepancy may reflect differences in [population/method/time period]."

  PART 3 — MECHANISMS (1 paragraph)
  Why might this finding be true?
  What is the biological, psychological, social, or economic mechanism?
  Cite theoretical frameworks.
  "This finding is consistent with [framework/theory], which proposes
   that [mechanism]."

  PART 4 — IMPLICATIONS (1 paragraph)
  What should practitioners, policymakers, or future researchers do
  differently because of your findings?
  Be specific. "Future research should study X" is weak.
  "These findings suggest that interventions targeting [mechanism]
   among [population] could reduce [outcome] by addressing [pathway]."

  PART 5 — LIMITATIONS (1 paragraph)
  List your three to five main limitations.
  For each: state it, then state what you did to minimise it.
  "A limitation of this study is [X]. However, we addressed this by [Y]."
  Never end the limitations paragraph on a limitation.
  End with a strength: "Despite these limitations, this study is the
  first to [novel contribution]."

DISCUSSION FAILURE MODES:
  × Repeating the results. The discussion interprets. It does not repeat.
  × Overclaiming causality from observational data.
    "X causes Y" → "X was associated with Y, consistent with a causal pathway,
    though our design cannot establish causality."
  × Vague implications. "More research is needed." — What research? By whom?
  × Hiding from limitations. Reviewers find them anyway.
    Own them first. Control the framing.
```

---

## Section 6 — Conclusion

```
ONE PARAGRAPH. MAXIMUM 150 WORDS.

STRUCTURE:
  → Restate what you found (one sentence)
  → State the significance for the field (one sentence)
  → State the implication for practice or policy (one sentence)
  → State what should happen next (one sentence — specific, not "more research")

CONCLUSION FAILURE MODES:
  × Introducing new information. Everything in the conclusion must be in the paper.
  × Repeating the abstract. The conclusion is not a summary. It is a verdict.
  × "In conclusion, this study showed..." — cut "in conclusion". Start with the finding.
```

---

## Output File: draft_sections.md

```markdown
# Draft Sections
Pipeline step: 4 of 6 — ambursaResearch
Date: [date]
Word count: [X]

---

## Title
[Working title — revise after results are drafted]

## Abstract
Background: [2 sentences]
Objective: [1 sentence]
Methods: [2–3 sentences]
Results: [2–4 sentences with numbers]
Conclusions: [1–2 sentences]
Keywords: [5–8 terms]

---

## 1. Introduction
[Full text — target 400–600 words, 4 paragraphs]

---

## 2. Methods
[Full text from study_design.md, refined]

---

## 3. Results
[Full text with tables/figures described]

---

## 4. Discussion
[Full text — 5 parts]

---

## 5. Conclusion
[Full text — max 150 words]

---

## Pipeline Status
Step 1 ✅ topic-validator    → topic_brief.md
Step 2 ✅ lit-reviewer       → literature_map.md
Step 3 ✅ method-architect   → study_design.md
Step 4 ✅ paper-writer       → draft_sections.md
Step 5 ⬜ revision-engine    → revision_log.md
Step 6 ⬜ submission-ready   → submission_package.md
```

---

## Review Gate (MANDATORY)

After saving `draft_sections.md`, present this EXACTLY:

```
✅ Full draft complete. Saved to draft_sections.md.

📋 Draft Summary:
- Sections complete: [N/6]
- Word count: [X] words
- Tables/figures: [N]
- Citations: [N]

👉 You can:
  - Approve → say "approved" or "move to revision"
  - Rewrite a section → say "rewrite [section name]: [specific issue]"
  - Strengthen the discussion → say "strengthen: [specific part]"
  - Fix results → say "fix results: [what is wrong]"

⏸️ Waiting for approval before Revision Engine runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `move to revision`, `revision engine`,
`proceed`, `next`, `go`, `draft done`, `start revising`
