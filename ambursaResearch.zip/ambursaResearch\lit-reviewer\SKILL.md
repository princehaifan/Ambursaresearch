---
name: lit-reviewer
description: >
  Step 2 of 6 in the ambursaResearch Pipeline. Maps the existing literature
  systematically, builds the evidence base for your gap statement, identifies
  the key papers, debates, and frameworks in your field, and produces a
  structured literature map that becomes the backbone of your Introduction
  and Discussion sections. Saves as literature_map.md.
---

# Literature Reviewer

You have a validated topic.
Now you need to understand the field.
Not all of it. Enough of it.
The researcher who tries to read everything never starts writing.
The researcher who reads too little gets destroyed at peer review.
Your job is not to summarise every paper ever written on your topic.
Your job is to map the evidence relevant to YOUR gap —
to show reviewers that you know the field,
that you know the debate,
and that you know exactly where your paper fits.
This skill teaches you how to read with intention.
Save as `literature_map.md`.

---

## Prerequisites

```
READ FIRST: topic_brief.md → research question, gap statement, journal target
```

---

## Step 1 — The Search Strategy

```
BUILD YOUR SEARCH BEFORE YOU SEARCH.

THE THREE-TIER SEARCH:

  TIER 1 — SEED PAPERS (5–10 papers)
  Start with the papers you already know.
  The papers that made you care about this topic.
  The papers cited in every other paper in your field.
  These are your anchors.

  TIER 2 — SYSTEMATIC SEARCH (20–50 papers)
  Build a search string from your gap statement.
  Extract: population terms + intervention/exposure terms + outcome terms
  Combine with AND / OR in PubMed, Google Scholar, or your MCP tool.

  EXAMPLE SEARCH STRING:
  ("sleep duration" OR "sleep deprivation") AND
  ("cardiovascular risk" OR "hypertension") AND
  ("shift workers" OR "night shift") AND
  ("sub-Saharan Africa" OR "low-income countries")

  TIER 3 — FORWARD AND BACKWARD CITATION SEARCH
  Pick your 3 most important seed papers.
  → Backward: who do THEY cite? (seminal papers, foundational methods)
  → Forward: who has CITED them since? (recent developments, challenges)

  THE STOPPING RULE:
  Stop searching when new papers are not introducing new ideas.
  You are saturated when: the same 10–15 papers keep appearing.
  Saturation = your search is complete.
```

---

## Step 2 — The Literature Map

```
DO NOT READ EVERY PAPER IN FULL.
READ STRATEGICALLY.

FOR EACH PAPER, EXTRACT:
  → Authors, year, journal
  → Study design (RCT, cohort, systematic review, qualitative, modelling)
  → Population (who, where, when)
  → Key finding (one sentence)
  → Limitation acknowledged by the authors
  → Relevance to YOUR gap (high / medium / background)

THE FOUR CATEGORIES — SORT ALL PAPERS INTO THESE:

  CATEGORY 1: FOUNDATIONAL (5–10 papers)
  Papers that established the field. Everyone cites these.
  You will cite them in your introduction.

  CATEGORY 2: DIRECT COMPARATORS (5–15 papers)
  Papers closest to YOUR question. Similar population, outcome, or method.
  You will compare your findings to these in your discussion.

  CATEGORY 3: THE GAP PAPERS (3–5 papers)
  Papers that explicitly call for the research you are doing.
  Authors who say: "future studies should examine X."
  Where X is your paper.
  These are gold. Cite them when you justify your gap.

  CATEGORY 4: CONFLICTING EVIDENCE (2–5 papers)
  Papers whose findings contradict each other.
  Disagreements in the literature.
  Your paper may resolve one of these conflicts — or add to the debate.
  Either way: acknowledge them.
```

---

## Step 3 — The Debate Map

```
EVERY FIELD HAS OPEN DEBATES. FIND YOURS.

THE THREE DEBATE TYPES:

  TYPE A: EMPIRICAL DEBATE
  Two groups of studies find different results.
  Example: "Studies in Western populations find X. Studies in Asian
  populations find Y. The mechanism is disputed."
  Your paper: adds evidence to one side, or explains the discrepancy.

  TYPE B: METHODOLOGICAL DEBATE
  Researchers disagree about how to measure or study the problem.
  Example: "Some studies use self-reported data; others use objective
  measures. Studies disagree on whether this affects results."
  Your paper: uses a different or improved method, or directly tests
  whether the method choice matters.

  TYPE C: CONCEPTUAL DEBATE
  Researchers disagree about the theory or framework.
  Example: "Social capital theory predicts X. Social conflict theory
  predicts Y. No study has tested these competing predictions."
  Your paper: tests the competing predictions.

  INSTRUCTION:
  Identify which debate type your field has.
  Your paper is a contribution to that debate.
  State clearly which side you are on, or what you will add.
```

---

## Step 4 — The Introduction Architecture

```
YOUR LITERATURE MAP BECOMES YOUR INTRODUCTION.
HERE IS THE STRUCTURE.

PARAGRAPH 1: THE FIELD (5–8 sentences)
  → What is the problem? (Why does the field exist?)
  → How big is the problem? (Scale, prevalence, burden — cite foundational papers)
  → What do we know so far? (2–3 key findings from foundational papers)

PARAGRAPH 2: THE DEBATE (4–6 sentences)
  → Where is the evidence inconsistent or incomplete?
  → What is the methodological or empirical debate?
  → Why has this not been resolved?

PARAGRAPH 3: THE GAP (3–5 sentences)
  → State your gap statement (from topic_brief.md)
  → Cite the gap papers (researchers who called for this study)
  → Explain why closing this gap matters for science OR practice

PARAGRAPH 4: THIS PAPER (2–4 sentences)
  → "In this paper, we examine..."
  → State your research question
  → State your method in one sentence
  → State what your contribution will be

  RULE: Never start paragraph 4 with "This paper aims to..."
         Start with what you DO: "We examine", "We test", "We analyse", "We report"
```

---

## Step 5 — The 15-Paper Core Set

```
FROM ALL YOUR PAPERS, SELECT THE 15 MOST IMPORTANT.

THE SELECTION CRITERIA:
  → 5 foundational papers (everyone cites these)
  → 5 direct comparators (closest to YOUR study)
  → 3 gap papers (they called for YOUR study)
  → 2 conflicting evidence papers (the debate your paper enters)

THESE 15 PAPERS ARE YOUR CORE SET.
You will cite these in almost every section.
You know them well enough to explain them from memory.
If a reviewer asks about one, you can answer immediately.

For the remaining papers in your map:
They are background — cite where relevant, but do not build your argument on them.
```

---

## Output File: literature_map.md

```markdown
# Literature Map
Pipeline step: 2 of 6 — ambursaResearch
Date: [date]

---

## Search Strategy
Database(s) used: [PubMed / Google Scholar / MCP tool / other]
Search string: [exact string]
Papers found: [N]
Papers after screening: [N]
Saturation reached: YES / NO

---

## Core Set — 15 Papers

### Foundational (5)
1. [Author, Year. Title. Journal. Key finding. Relevance.]
2. [...]
3. [...]
4. [...]
5. [...]

### Direct Comparators (5)
6. [Author, Year. Title. Journal. Key finding. What differs from yours.]
7. [...]
8. [...]
9. [...]
10. [...]

### Gap Papers (3)
11. [Author, Year. Title. Journal. What they called for. How yours answers.]
12. [...]
13. [...]

### Conflicting Evidence (2)
14. [Author, Year. Journal. Finding. How they conflict.]
15. [Author, Year. Journal. Finding. How they conflict.]

---

## The Debate
Debate type: EMPIRICAL / METHODOLOGICAL / CONCEPTUAL
Description: [2–3 sentences describing the open debate]
Your paper's position: [which side, or what you add]

---

## Introduction Architecture (Draft)
Para 1 — The field:
  [3–5 bullet points of key claims + citations]
Para 2 — The debate:
  [2–3 bullet points of contested findings + citations]
Para 3 — The gap:
  [Gap statement from topic_brief.md + gap paper citations]
Para 4 — This paper:
  [One-sentence version of your research question and method]

---

## Pipeline Status
Step 1 ✅ topic-validator    → topic_brief.md
Step 2 ✅ lit-reviewer       → literature_map.md
Step 3 ⬜ method-architect   → study_design.md
Step 4 ⬜ paper-writer       → draft_sections.md
Step 5 ⬜ revision-engine    → revision_log.md
Step 6 ⬜ submission-ready   → submission_package.md
```

---

## Review Gate (MANDATORY)

After saving `literature_map.md`, present this EXACTLY:

```
✅ Literature map complete. Saved to literature_map.md.

📋 Literature Summary:
- Papers in core set: 15
- Debate type: [EMPIRICAL / METHODOLOGICAL / CONCEPTUAL]
- Key gap papers found: [N] (they called for YOUR study)
- Introduction architecture: 4 paragraphs mapped

👉 You can:
  - Approve → say "approved" or "move to methods"
  - Add a paper → say "add: [citation]"
  - Reframe the debate → say "debate: [your framing]"
  - Rewrite introduction structure → say "intro: [change]"

⏸️ Waiting for approval before Method Architect runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `move to methods`, `method architect`,
`proceed`, `next`, `go`, `lit done`, `start methods`
