---
name: submission-ready
description: >
  Step 6 of 6 in the ambursaResearch Pipeline. Assembles the complete
  submission package: cover letter, author contributions, conflict of interest,
  data availability, ethics, acknowledgements, supplementary files, and
  journal submission checklist. Guides you through the online submission system.
  Also sets expectations for peer review and how to respond to reviewer comments.
  Saves as submission_package.md.
---

# Submission Ready

The paper is revised.
The revision log is clean.
The pre-submission checklist is complete.
Now you submit.
Submission is not the end.
It is the beginning of a conversation with the field.
Peer review is not an obstacle.
It is the process by which your work earns its place in the literature.
Understand what comes next,
prepare the full submission package,
and you will navigate peer review without being derailed by it.
This skill builds the submission package,
sets your expectations for review,
and gives you the tools to respond to any outcome.
Save as `submission_package.md`.

---

## Prerequisites

```
READ FIRST: revision_log.md   → pre-submission checklist status
READ SECOND: topic_brief.md   → target journal, research question
READ THIRD: draft_sections.md → final paper draft
```

---

## Step 1 — The Cover Letter

```
THE COVER LETTER IS THE EDITOR'S FIRST IMPRESSION OF YOUR PAPER.
It is not a summary of the paper. It is a pitch.
It answers: why should this journal publish this paper, now?

COVER LETTER STRUCTURE:

  PARAGRAPH 1 — SUBMISSION STATEMENT
  "We are pleased to submit our [article type: original article / systematic
   review / brief report / etc.] entitled '[TITLE]' for consideration for
   publication in [Journal Name]."

  PARAGRAPH 2 — THE PITCH (3–5 sentences)
  → State the gap: "To our knowledge, no study has examined [gap]."
  → State what you did: "In this [study type], we [method] among [population]."
  → State the main finding: "We found that [result]."
  → State the significance: "These findings have implications for [audience]
     because [why it matters]."

  PARAGRAPH 3 — WHY THIS JOURNAL
  "We believe this paper is well-suited to [Journal Name] because
   [2 specific reasons — recent papers in this space / stated scope / audience]."
  Cite 1–2 papers recently published in this journal on a related topic.
  This shows you know the journal. It is the most underused move in cover letters.

  PARAGRAPH 4 — LOGISTICS
  → Confirm the paper is not under review elsewhere (required by most journals)
  → Suggested reviewers (optional but useful — 3–5 names with institutional emails)
  → Opposed reviewers (competitors, conflicted parties — optional)
  → Data availability statement (brief version)
  → Conflict of interest (brief version)

  SIGN-OFF
  "We look forward to hearing from you."
  Lead author's name, institution, email.

COVER LETTER FAILURE MODES:
  × Too long (>500 words). Editors skim.
  × Summarising the abstract. The editor will read the abstract.
  × "We hope you will consider..." — weak. "We believe this paper
    is well-suited to X because Y" — confident and specific.
  × Not naming the journal. Generic cover letters are obvious.
  × No suggested reviewers. When you can name experts in your field:
    do it. It speeds up desk assignment.
```

---

## Step 2 — Mandatory Companion Statements

```
MOST JOURNALS NOW REQUIRE ALL OF THE FOLLOWING.
Prepare each before you open the submission portal.

AUTHOR CONTRIBUTIONS (CRediT taxonomy):
  List every author and their contribution.
  Use these standardised roles:
  Conceptualization, Methodology, Software, Validation, Formal analysis,
  Investigation, Resources, Data curation, Writing (original draft),
  Writing (review and editing), Visualization, Supervision, Funding acquisition.

  EXAMPLE:
  "[Author 1]: Conceptualization, Methodology, Writing – original draft.
   [Author 2]: Data curation, Formal analysis, Writing – review and editing.
   [Author 3]: Supervision, Funding acquisition."

CONFLICT OF INTEREST:
  "The authors declare no conflict of interest."
  OR: "[Author X] has received [funding/honoraria/consultancy fees] from
  [entity], which had no role in the design, conduct, or reporting of this study."

DATA AVAILABILITY:
  OPTION A (data available):
  "The data that support the findings of this study are available at
  [repository/DOI], reference number [X]."

  OPTION B (data not shareable):
  "The data that support the findings of this study are not publicly available
  due to [reason: ethical restrictions / patient privacy / institutional policy].
  Anonymised data may be available upon reasonable request to the
  corresponding author."

  OPTION C (secondary data):
  "This study used publicly available data from [source].
  The data are available at [URL/DOI]."

ETHICS:
  "Ethical approval was obtained from [institution] (reference [X]).
  All participants provided written informed consent."
  OR:
  "Ethics approval was not required for this study under [applicable framework]
  because [reason]."

FUNDING:
  "This work was supported by [funder, grant number X]."
  OR:
  "This research received no specific funding from any public, commercial,
  or not-for-profit funding agency."

ACKNOWLEDGEMENTS:
  Thank any contributors not listed as authors (research assistants,
  statistical consultants, clinical staff).
  Mention any datasets or tools used.
  "The authors thank [name] for [specific contribution]."
```

---

## Step 3 — What Happens After Submission

```
UNDERSTAND THE TIMELINE. MANAGE YOUR EXPECTATIONS.

THE FOUR OUTCOMES OF PEER REVIEW:

  OUTCOME 1: DESK REJECTION (most common, fastest)
  Received: usually within 1–7 days.
  Reason: out of scope, insufficient novelty, format issues, or poor fit.
  What to do: read the rejection letter carefully.
    → If "out of scope": move to your second-choice journal without revision.
    → If "insufficient novelty": read the editor's comments.
      This is feedback. Use it to strengthen the gap statement.
    → Resubmit to your next journal within one week. Do not delay.

  OUTCOME 2: MAJOR REVISION
  Received: 6–16 weeks typically.
  Reason: the paper has merit but requires substantial changes.
  What to do: THIS IS GOOD NEWS. Major revision means acceptance is possible.
    → Read all reviewer comments before reacting.
    → For every comment: plan a response.
    → Response options: (a) agree and change, (b) disagree but add nuance,
      (c) disagree and explain why (with evidence).
    → Never dismiss a comment without addressing it.
    → Write a point-by-point response letter (see Step 4).

  OUTCOME 3: MINOR REVISION
  Received: 6–16 weeks typically.
  Reason: the paper is nearly ready. Small changes needed.
  What to do: address every comment within 2–4 weeks and resubmit.
    → Minor revision = very high probability of acceptance if addressed properly.
    → Write a brief response letter addressing each point.
    → Do not introduce new analyses unless specifically asked.

  OUTCOME 4: ACCEPTANCE
  Received: after revision round(s), or directly (rare).
  What to do: read the proofs carefully. Check every number.
    → Proof errors that make it into print are your responsibility.
    → Check: author names, affiliations, figures, tables, abstract word count,
      reference formatting.
    → Return proofs within the stated deadline (usually 48–72 hours).
```

---

## Step 4 — The Reviewer Response Letter

```
THE RESPONSE LETTER IS AS IMPORTANT AS THE PAPER.
A poorly written response can reverse a positive decision.
A well-written response can rescue a borderline decision.

STRUCTURE:

  OPENING:
  "We thank the editors and reviewers for their careful reading of our
  manuscript and for their constructive comments. We have revised the
  manuscript in line with the reviewers' suggestions and believe the
  paper is substantially strengthened."

  FOR EACH REVIEWER, FOR EACH COMMENT:
  Reviewer 1, Comment 1:
  > [Paste the reviewer's exact comment in a quote block]
  Response: [Your response — typically 2–5 sentences]
  Action taken: [Specific change made, with line numbers or section reference]

  THE THREE RESPONSE TYPES:

  TYPE A — AGREE AND CHANGE:
  "We thank Reviewer 1 for this observation. We agree that [issue].
  We have [specific action — added/amended/removed X on p.X, lines X–X]."

  TYPE B — PARTIALLY AGREE:
  "We appreciate this comment. We agree that [part of concern] and have
  [change]. However, we respectfully note that [reason the full change
  is not warranted], consistent with [citation]."

  TYPE C — DISAGREE RESPECTFULLY:
  "We thank Reviewer 2 for raising this point. We respectfully disagree
  because [evidence/citation/logical reason]. [Additional evidence.]
  We have added a sentence acknowledging this perspective on p.X:
  '[exact text added]'."

RESPONSE LETTER RULES:
  → Address every comment. Even if the change is "no change made." Explain why.
  → Quote the reviewer's comment verbatim before each response.
  → Reference exact page and line numbers for every change.
  → Never be defensive or dismissive. Reviewers are anonymous but human.
  → If you disagree: cite evidence. Never just assert.
  → If the reviewer is wrong about a fact: politely correct with a citation.
```

---

## Step 5 — The FastTrack Guarantee Framework

```
IF YOU ARE STILL WITH THIS PIPELINE AFTER 90 DAYS:

THE THREE CONDITIONS THAT KEEP THE PIPELINE ACTIVE:
  □ 5–10 hours per week committed to the research
  □ Attending (or reviewing) live workshop sessions
  □ Completing sections and submitting for feedback

IF YOU HIT A WALL:
  Stalling has three causes:
  CAUSE 1: The topic is wrong. → Return to topic-validator with new constraints.
  CAUSE 2: The methods are blocked. → Return to method-architect. Simplify scope.
  CAUSE 3: Writing paralysis. → Write one bad paragraph today. Fix it tomorrow.

THE PIPELINE DOES NOT END AT SUBMISSION.
If your paper is rejected: diagnose, pivot, resubmit.
  → Desk rejection: journal fit problem. Move to next journal.
  → Post-review rejection: quality problem. Use reviewer comments as a revision brief.
    Return to revision-engine with the reviewer comments.
    Re-run Pass 1 using reviewer comments as the hostile reviewer.
  → Under major revision: not a rejection. Treat it as a revision brief.
    Return to revision-engine. Address every comment.

YOU FINISH WHEN THE PAPER IS PUBLISHED. NOT BEFORE.
```

---

## Output File: submission_package.md

```markdown
# Submission Package
Pipeline step: 6 of 6 — ambursaResearch ✅ COMPLETE
Date: [date]

---

## Target Journal
Journal: [journal name]
Submission portal: [URL]
Expected decision time: [X weeks]
Backup journal: [journal name]

---

## Cover Letter
[Full cover letter text — ready to paste]

---

## Author Contributions
[CRediT statement]

---

## Conflict of Interest
[Statement]

---

## Data Availability
[Statement]

---

## Ethics
[Statement]

---

## Funding
[Statement]

---

## Acknowledgements
[Text]

---

## Submission Checklist
□ Manuscript (anonymised if required)
□ Cover letter
□ Author contribution statement
□ COI declaration
□ Ethics statement
□ Data availability statement
□ Figures (high resolution, correct format)
□ Tables (editable, not image)
□ Supplementary material (if any)
□ Suggested reviewers list (names + emails)

---

## Post-Submission Log
Submitted: [date]
Outcome: PENDING / DESK REJECTION / MAJOR REVISION / MINOR REVISION / ACCEPTED
Response due: [date]
Next action: [what to do]

---

## Pipeline Status — COMPLETE
Step 1 ✅ topic-validator    → topic_brief.md
Step 2 ✅ lit-reviewer       → literature_map.md
Step 3 ✅ method-architect   → study_design.md
Step 4 ✅ paper-writer       → draft_sections.md
Step 5 ✅ revision-engine    → revision_log.md
Step 6 ✅ submission-ready   → submission_package.md
```

---

## Pipeline Complete Summary (MANDATORY)

After saving `submission_package.md`, present this EXACTLY:

```
✅ ambursaResearch Pipeline Complete.

📊 PIPELINE SUMMARY:
  Step 1 ✅ topic-validator    → topic_brief.md
  Step 2 ✅ lit-reviewer       → literature_map.md
  Step 3 ✅ method-architect   → study_design.md
  Step 4 ✅ paper-writer       → draft_sections.md
  Step 5 ✅ revision-engine    → revision_log.md
  Step 6 ✅ submission-ready   → submission_package.md

📋 DELIVERABLES READY:
  → Foundation:   topic_brief.md       (validated gap, journal target)
  → Literature:   literature_map.md    (core set, debate, intro architecture)
  → Methods:      study_design.md      (design, PICO, analysis plan)
  → Draft:        draft_sections.md    (complete paper draft)
  → Revision:     revision_log.md      (3-pass review, pre-submission checklist)
  → Submission:   submission_package.md (cover letter, statements, checklist)

🎯 PAPER STATUS:
  Research question: [one sentence]
  Target journal:    [journal name]
  Submission status: READY TO SUBMIT / SUBMITTED / UNDER REVIEW / ACCEPTED
  Next action:       [what happens now]

✅ You have done what most researchers never do:
   validated the gap before writing,
   designed a study a reviewer cannot fault,
   and prepared a submission that is ready for the field.

   The pipeline does not end at submission.
   If your paper comes back — rejected or revised —
   return to the step that matches the feedback and continue.
   We stay with the paper until it is published.
```

The pipeline is now complete.
No further steps required unless a revision or resubmission is needed.
