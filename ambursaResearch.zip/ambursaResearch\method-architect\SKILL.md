---
name: method-architect
description: >
  Step 3 of 6 in the ambursaResearch Pipeline. Designs your study methodology:
  chooses the right study design for your question, defines your sample and
  data, specifies your analysis plan, and writes the Methods section to
  journal standard. A reviewer who cannot fault your methods cannot reject
  your paper on methodological grounds. Saves as study_design.md.
---

# Method Architect

A good research question with a bad method is a rejected paper.
A mediocre research question with a rigorous method gets published.
Methods are where papers are accepted or rejected at peer review.
Reviewers who cannot fault your methods cannot reject your paper.
Your goal in this step is not just to design a study.
Your goal is to design a study that is impossible to dismiss.
Transparent, pre-specified, reproducible, appropriate.
Every methodological choice has a reason.
Every reason has a citation.
Save as `study_design.md`.

---

## Prerequisites

```
READ FIRST: topic_brief.md   → research question, feasibility constraints
READ SECOND: literature_map.md → methods used by direct comparators
```

---

## Step 1 — Study Design Selection

```
MATCH THE DESIGN TO THE QUESTION.

RESEARCH QUESTION TYPE → APPROPRIATE DESIGN:

  "What is the prevalence / how common is X?"
  → Cross-sectional survey, registry analysis, secondary data analysis

  "Does X cause Y?" (you have an intervention or exposure)
  → RCT (if you can randomise), cohort study, natural experiment,
    difference-in-differences, regression discontinuity

  "What is the lived experience of X?"
  → Qualitative: interviews, focus groups, ethnography

  "What does the evidence show across studies?"
  → Systematic review (with or without meta-analysis)
  → Scoping review (mapping the field, not synthesising effect sizes)

  "What predicts X?"
  → Regression analysis on observational data
  → Predictive modelling (machine learning, if appropriate)

  "Does X work in a new population/context?"
  → Replication study (same method, new setting)
  → Secondary data analysis

  THE DESIGN RULE:
  Choose the HIGHEST-QUALITY design you can ACTUALLY execute.
  Not the ideal design. The feasible design.
  Then acknowledge the limitation explicitly in your discussion.
  Reviewers respect honesty about design constraints.
  They reject papers that pretend constraints do not exist.
```

---

## Step 2 — The PICO/PEO Framework

```
DEFINE YOUR STUDY PRECISELY.

FOR QUANTITATIVE RESEARCH:
  PICO FORMAT:
  P — Population:  Who are your participants? (inclusion/exclusion criteria)
  I — Intervention (or Exposure): What is the independent variable?
  C — Comparator: What is the comparison group (if any)?
  O — Outcome: What are you measuring? (primary and secondary outcomes)

FOR QUALITATIVE RESEARCH:
  PEO FORMAT:
  P — Population: Who are your participants?
  E — Exposure/Experience: What phenomenon are you exploring?
  O — Outcome/Theme: What are you trying to understand?

FOR SYSTEMATIC REVIEW:
  PRISMA-compliant PICO applied to inclusion/exclusion criteria.
  Register on PROSPERO before data extraction begins.

WRITE YOUR PICO/PEO IN ONE TABLE.
Every methodological choice flows from this table.
If a choice does not serve the PICO: cut it.
```

---

## Step 3 — Sample and Data

```
THREE SAMPLE QUESTIONS TO ANSWER BEFORE YOU WRITE A WORD.

QUESTION 1: WHERE DOES YOUR DATA COME FROM?
  → Primary data (you collect it): survey, interview, experiment
  → Secondary data (already collected): registry, database, published records
  → Systematic review: published papers are your data

  KEY: Can you access it? Do you need ethical approval?
  If ethical approval needed: factor in the timeline now.

QUESTION 2: HOW MANY PARTICIPANTS DO YOU NEED?
  FOR QUANTITATIVE RESEARCH: Run a power calculation.
  Standard: 80% power, alpha = 0.05.
  Use G*Power (free) or report the formula.
  Document the effect size assumption and its source.
  Reviewers WILL ask about this.

  FOR QUALITATIVE RESEARCH: Report purposive sampling.
  Typical: 10–30 participants for interviews (until thematic saturation).
  Do not say "we interviewed 15 participants because that is what we could get."
  Say: "We sampled until thematic saturation was reached."

  FOR SYSTEMATIC REVIEW: No power calculation.
  Report search strategy and PRISMA flow diagram.

QUESTION 3: WHO IS EXCLUDED, AND WHY?
  Every inclusion criterion has a reason.
  Every exclusion criterion has a reason.
  State them. Cite them where possible.
  Vague exclusion criteria are a reviewer's first attack point.
```

---

## Step 4 — Analysis Plan

```
PRE-SPECIFY YOUR ANALYSIS.
"We will analyse the data" is not an analysis plan.

FOR QUANTITATIVE RESEARCH:
  State:
  → Software (R, Stata, SPSS, Python — be specific about packages)
  → Primary analysis (the main test or model)
  → Secondary analyses (subgroup analyses, sensitivity analyses)
  → How you will handle missing data (complete case / multiple imputation)
  → How you will handle confounding (which variables, which model)

  THE CONFOUNDING RULE:
  List every variable you will adjust for in your main model.
  For each one: why are you including it?
  "We included age because it is associated with both exposure and outcome
   based on [citation]."
  Every confounder without a reason is a reviewer question.

FOR QUALITATIVE RESEARCH:
  State:
  → Framework (thematic analysis, grounded theory, IPA, discourse analysis)
  → Software (NVivo, Atlas.ti, manual)
  → How themes were developed (inductive, deductive, hybrid)
  → How you ensured rigour (member checking, negative case analysis,
    peer debriefing, audit trail, reflexivity statement)

FOR SYSTEMATIC REVIEW:
  State:
  → Search databases and dates
  → Screening process (number of reviewers, disagreement resolution)
  → Data extraction template
  → Quality assessment tool (GRADE, ROBINS, Cochrane RoB, CASP)
  → Synthesis method (narrative synthesis / meta-analysis — if meta, state model)
```

---

## Step 5 — The Methods Section Template

```
WRITE THE METHODS SECTION BEFORE YOU COLLECT DATA.
(Or if data is already collected: write it as if you pre-specified everything.)

STRUCTURE (adapt to your design):

  2.1 STUDY DESIGN
  One paragraph. What type of study is this and why is it appropriate
  for your research question?

  2.2 PARTICIPANTS (or DATA SOURCES for secondary data / systematic review)
  Who, where, when. Inclusion and exclusion criteria. Sample size and rationale.

  2.3 MEASURES / VARIABLES
  What are you measuring? How? Define every variable operationally.
  Reliability and validity of instruments (if applicable).

  2.4 PROCEDURE
  What happened, in order? Data collection timeline.
  Any ethical approvals (institutional review board / ethics committee).

  2.5 ANALYSIS
  Your pre-specified analysis plan. Software, models, handling of missing data.

  2.6 POSITIONALITY (qualitative only)
  Who are you in relation to this research?
  How might your background affect data collection or interpretation?

RULE: Write methods so that a stranger could replicate your study.
If they could not: your methods section is not complete.
```

---

## Step 6 — The Reviewer Stress Test

```
READ YOUR METHODS AS A HOSTILE REVIEWER.

THE FIVE REVIEWER ATTACKS:

  ATTACK 1: SELECTION BIAS
  "The sample is not representative of the population you claim to study."
  → Your defence: state how you selected participants and why the
    selection is appropriate for your research question.

  ATTACK 2: MEASUREMENT ERROR
  "Your outcome measure is unreliable / not validated."
  → Your defence: cite the validation study for every instrument.
    If the instrument is not validated: acknowledge this as a limitation.

  ATTACK 3: CONFOUNDING
  "You haven't controlled for [obvious variable]."
  → Your defence: list every confounder in your model and why.
    If you couldn't control for something: acknowledge it.

  ATTACK 4: GENERALISABILITY
  "These findings only apply to this specific sample."
  → Your defence: clearly state the population your findings apply to.
    Do not overclaim. The scope of your claim = the scope of your sample.

  ATTACK 5: UNDERPOWERED
  "The study is too small to detect an effect."
  → Your defence: power calculation with documented assumptions.
    If underpowered: pre-register the study as exploratory.
    Exploratory findings are publishable. Underpowered confirmatory studies are not.

RULE: Every attack has a defence. Find the attacks before the reviewer does.
Build the defences into the methods section itself.
```

---

## Output File: study_design.md

```markdown
# Study Design
Pipeline step: 3 of 6 — ambursaResearch
Date: [date]

---

## Study Design
Design type: [RCT / cohort / cross-sectional / systematic review / qualitative / other]
Justification: [one sentence: why this design for this question]

---

## PICO / PEO
P — Population: [description + inclusion/exclusion criteria]
I/E — Intervention/Exposure: [description]
C — Comparator: [description or N/A]
O — Outcome: [primary outcome] / [secondary outcomes]

---

## Sample and Data
Data source: [primary / secondary / published papers]
Sample size: [N] — Justification: [power calculation or saturation rationale]
Ethics approval: REQUIRED / NOT REQUIRED — Status: [approved / applied / N/A]

---

## Analysis Plan
Software: [R / Stata / SPSS / NVivo / other]
Primary analysis: [one sentence]
Confounders / covariates: [list]
Missing data: [approach]
Sensitivity analyses: [list or none]

---

## Reviewer Stress Test
Attack 1 (Selection bias): [your defence]
Attack 2 (Measurement): [your defence]
Attack 3 (Confounding): [your defence]
Attack 4 (Generalisability): [scope of claim]
Attack 5 (Power): [power calculation or exploratory framing]

---

## Methods Section Draft
[Paste draft here — 2.1 through 2.5 / 2.6]

---

## Pipeline Status
Step 1 ✅ topic-validator    → topic_brief.md
Step 2 ✅ lit-reviewer       → literature_map.md
Step 3 ✅ method-architect   → study_design.md
Step 4 ⬜ paper-writer       → draft_sections.md
Step 5 ⬜ revision-engine    → revision_log.md
Step 6 ⬜ submission-ready   → submission_package.md
```

---

## Review Gate (MANDATORY)

After saving `study_design.md`, present this EXACTLY:

```
✅ Study design complete. Saved to study_design.md.

📋 Methods Summary:
- Design: [type]
- Sample: [N] — [data source]
- Primary analysis: [one sentence]
- Reviewer stress test: [N/5 attacks defended]
- Ethics: [approved / not required / pending]

👉 You can:
  - Approve → say "approved" or "move to writing"
  - Change design → say "design: [alternative]"
  - Adjust analysis → say "analysis: [change]"
  - Address a reviewer attack → say "attack [N]: [your response]"

⏸️ Waiting for approval before Paper Writer runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `move to writing`, `paper writer`,
`proceed`, `next`, `go`, `methods done`, `start writing`
