---
name: revision-engine
description: >
  Step 5 of 6 in the ambursaResearch Pipeline. Runs three revision passes on
  the complete draft: (1) a hostile peer reviewer simulation across all
  sections, (2) a journal-fit check against your target journal, and
  (3) an AI-mark and clarity check to ensure the writing reads as yours.
  Produces a prioritised revision log with every actionable change.
  Saves as revision_log.md.
---

# Revision Engine

The draft is finished.
Now you become its harshest critic before anyone else does.
Peer review is not personal.
It is a process by which the field tests whether your contribution is real.
Every objection a reviewer raises is an objection you could have anticipated.
Every rejection could have been a revision if you had caught the problem first.
This skill runs three revision passes before you submit.
Pass one: the hostile reviewer.
Pass two: the journal fit check.
Pass three: the voice and clarity check.
You will not submit until all three are clean.
Save as `revision_log.md`.

---

## Prerequisites

```
READ FIRST: draft_sections.md → complete paper draft
READ SECOND: topic_brief.md   → target journal, gap statement
READ THIRD: study_design.md   → reviewer stress test from step 3
```

---

## Pass 1 — The Hostile Reviewer

```
READ THE ENTIRE DRAFT AS A REVIEWER WHO WANTS TO REJECT IT.
Your job is to find every reason to say no.
Then fix every reason before submission.

THE HOSTILE REVIEWER CHECKLIST:

TITLE:
  □ Does the title accurately describe what the paper does?
  □ Is it specific? ("A study of X in Y population" beats "A study of X")
  □ Does it match the journal's style? (some prefer declarative: "X is associated with Y")
  □ Is it under 15 words?

ABSTRACT:
  □ Does every number in the abstract match the numbers in the results?
  □ Does the abstract stand alone? (can a reader understand the paper from abstract alone?)
  □ Does it include effect sizes, not just p-values?
  □ Is it within the word limit for the target journal?

INTRODUCTION:
  □ Does the gap statement accurately describe what the literature lacks?
  □ Are there any claims without citations?
  □ Is the research question stated explicitly?
  □ Is the introduction within journal word limit?
  □ Could a hostile reviewer say "actually, [citation] already did this"?
    → If so: how is YOUR study different? State it.

METHODS:
  □ Is the study design appropriate for the research question?
    (A reviewer will state this explicitly if not.)
  □ Are all inclusion/exclusion criteria defined precisely?
  □ Is the sample size justified with a power calculation or saturation rationale?
  □ Are all instruments validated (and cited)?
  □ Is the analysis fully specified? (Which software, which model, which covariates?)
  □ Is the ethics statement present and complete?
  □ Could this study be replicated by a stranger reading only your methods?

RESULTS:
  □ Does every result in the text match the tables/figures exactly?
  □ Are confidence intervals reported for every estimate?
  □ Are p-values accompanied by effect sizes?
  □ Are all tables and figures self-contained with standalone titles and legends?
  □ Is any result presented without being relevant to the research question?
    → If so: cut it, or move to supplementary material.

DISCUSSION:
  □ Is the main finding stated in the first sentence of the discussion?
  □ Are all comparisons to prior literature specific? (Not "consistent with
    previous findings" — which findings? Cite them.)
  □ For every inconsistency with prior work: is a reason offered?
  □ Is the mechanism section evidence-based, or speculative?
    (Speculation is fine if labelled: "While speculative, this may reflect...")
  □ Are the implications specific and actionable?
  □ Are all limitations acknowledged?
  □ For each limitation: is a mitigation strategy stated?
  □ Does the discussion overclaim causality from observational data?

CONCLUSION:
  □ Is the conclusion consistent with the results? (No overclaiming.)
  □ Is new information introduced? (It should not be.)
  □ Is the word count under 150 words?

REFERENCES:
  □ Are all citations formatted to the target journal's style?
  □ Are the most important papers (from core set) all cited?
  □ Are there any uncited claims?
  □ Are there any citations for claims that do not need them?
  □ Are there any broken or unverifiable citations?
```

---

## Pass 2 — Journal Fit Check

```
READ THE PAPER AGAINST THE TARGET JOURNAL.

FIVE JOURNAL FIT DIMENSIONS:

  DIMENSION 1: SCOPE FIT
  Is your paper clearly within the journal's stated scope?
  Compare your abstract to the journal's aims and scope statement.
  If you cannot point to a phrase in the journal's scope that describes
  your paper: either reframe your paper OR change the target journal.

  DIMENSION 2: AUDIENCE FIT
  Who reads this journal?
  Is your writing pitched at that audience?
  A clinical journal reader should not need to look up statistical terminology.
  A methods journal reader does not need the clinical background explained.
  Adjust depth of explanation accordingly.

  DIMENSION 3: FORMAT FIT
  Check the journal's author guidelines:
  → Word limit (abstract, main text, supplementary)
  → Reference limit and format (Vancouver, APA, Harvard, AMA)
  → Figure and table limits
  → Structured vs unstructured abstract
  → Required sections (some journals require Ethics, Data Availability, etc.)
  → Open access requirements and fees (if applicable)
  Document every deviation from requirements. Fix before submission.

  DIMENSION 4: IMPACT FIT
  Is your paper's contribution appropriate for this journal's impact level?
  Submitting a minor secondary analysis to Nature: will be desk-rejected.
  Submitting a genuinely novel multi-country RCT to a low-impact journal:
  leaves impact on the table.
  Calibrate your target to the actual novelty and rigour of your paper.

  DIMENSION 5: RECENT PAPERS FIT
  Search the last 2 years of publications in your target journal.
  Find the 3 papers most similar to yours.
  How does your paper compare in scope, methodology, and contribution?
  If your paper would not be out of place alongside them: good fit.
  If it feels like a different kind of paper: reconsider the target.
```

---

## Pass 3 — Voice and Clarity Check

```
THE DRAFT MUST READ AS YOUR WORK, NOT AS AI-ASSISTED GENERIC PROSE.

TEN CLARITY RULES:

  RULE 1: One idea per sentence.
  Split sentences with two ideas connected by "and" or "however."
  "X was associated with Y, and this finding suggests Z."
  → "X was associated with Y. This suggests Z."

  RULE 2: Active voice by default.
  "Data were collected" → "We collected data"
  (Exception: Methods sections in some journals use passive by convention.
  Check the journal's recent papers.)

  RULE 3: Cut weasel words.
  "It could be argued that..." → state it or don't.
  "Interestingly..." → delete.
  "Importantly..." → delete. Everything in a paper is important.
  "It is worth noting..." → just note it.
  "In terms of X..." → rewrite.

  RULE 4: Numbers under 10 as words, 10 and above as digits.
  (Unless journal style specifies otherwise. Check.)

  RULE 5: Every paragraph has one main claim.
  Read the first sentence of each paragraph.
  It should state the main claim.
  If it does not: rewrite the first sentence.

  RULE 6: Every claim in the discussion is in the results.
  If you discuss a finding that is not in the results section: add it, or remove it.

  RULE 7: Abbreviations defined on first use only.
  "World Health Organization (WHO)" — first use.
  "(WHO)" — all subsequent uses.
  Do not define abbreviations you use fewer than 3 times.

  RULE 8: Transitions between paragraphs are explicit.
  "Building on this finding..." / "In contrast..." / "To address this gap..." /
  "Despite this evidence..." — the reader should never be surprised by a paragraph.

  RULE 9: Tables and figures have parallel structure.
  If Table 1 uses "Mean (SD)," Table 2 must use "Mean (SD)" not "Mean ± SD."

  RULE 10: The conclusion matches the introduction.
  The gap you identified in the introduction must be the gap you addressed.
  The research question in the introduction must be the question you answered.
  Read introduction and conclusion together. They must be coherent.
```

---

## The Revision Log

```
FOR EACH ISSUE FOUND IN PASSES 1, 2, AND 3:

  LOG FORMAT:
  Priority: HIGH / MEDIUM / LOW
  Section: [Introduction / Methods / Results / Discussion / Abstract / Other]
  Issue: [What is wrong]
  Action: [What to change]
  Status: OPEN / IN PROGRESS / RESOLVED

  PRIORITY GUIDE:
  HIGH = will cause rejection if unaddressed
  MEDIUM = will cause major revision if unaddressed
  LOW = will cause minor revision; fix before submission
```

---

## The Pre-Submission Checklist

```
DO NOT SUBMIT UNTIL ALL ITEMS ARE CHECKED:

  □ All HIGH priority revision items: RESOLVED
  □ All MEDIUM priority revision items: RESOLVED
  □ Abstract matches the journal's word limit and structure
  □ Main text matches the journal's word limit
  □ All tables and figures formatted to journal style
  □ References formatted to journal style
  □ Ethics statement present (or justified absence)
  □ Author contributions statement written
  □ Conflict of interest statement written
  □ Data availability statement written (many journals now require this)
  □ Acknowledgements written
  □ Cover letter drafted (see submission-ready skill)
  □ Supplementary material compiled (if any)
  □ Co-authors have approved the final version
  □ The paper has been read aloud from start to finish at least once
```

---

## Output File: revision_log.md

```markdown
# Revision Log
Pipeline step: 5 of 6 — ambursaResearch
Date: [date]
Revision passes complete: [N/3]

---

## Pass 1 — Hostile Reviewer Issues
| Priority | Section | Issue | Action | Status |
|----------|---------|-------|--------|--------|
| HIGH | Methods | Power calculation missing | Add G*Power output | OPEN |
| MEDIUM | Discussion | Mechanism not cited | Add [citation] | OPEN |
| LOW | Abstract | Word count over limit | Cut 12 words | OPEN |

---

## Pass 2 — Journal Fit Issues
Target journal: [journal name]
| Dimension | Issue | Action | Status |
|-----------|-------|--------|--------|
| Format | Reference limit exceeded | Cut [N] references | OPEN |
| Scope | Methods section too detailed for readership | Compress to [X] words | OPEN |

---

## Pass 3 — Voice and Clarity Issues
| Rule | Location | Issue | Action | Status |
|------|----------|-------|--------|--------|
| Rule 3 | Discussion P2 | "Interestingly" | Delete | OPEN |
| Rule 1 | Results P1 | Compound sentence | Split | OPEN |

---

## Pre-Submission Checklist
[Copy checklist here and check items as they are completed]

---

## Pipeline Status
Step 1 ✅ topic-validator    → topic_brief.md
Step 2 ✅ lit-reviewer       → literature_map.md
Step 3 ✅ method-architect   → study_design.md
Step 4 ✅ paper-writer       → draft_sections.md
Step 5 ✅ revision-engine    → revision_log.md
Step 6 ⬜ submission-ready   → submission_package.md
```

---

## Review Gate (MANDATORY)

After saving `revision_log.md`, present this EXACTLY:

```
✅ Revision complete. Saved to revision_log.md.

📋 Revision Summary:
- Pass 1 (Hostile reviewer): [N] issues found — [N HIGH] high priority
- Pass 2 (Journal fit): [N] issues found
- Pass 3 (Voice/clarity): [N] issues found
- Total issues resolved: [N]
- Pre-submission checklist: [N/18] items checked

👉 You can:
  - Approve → say "approved" or "move to submission"
  - Address a specific issue → say "fix: [issue from log]"
  - Re-run a pass → say "rerun pass [1/2/3]"
  - Change target journal → say "retarget: [new journal]"

⏸️ Waiting for approval before Submission Ready runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `move to submission`, `submission ready`,
`proceed`, `next`, `go`, `revision done`, `ready to submit`
