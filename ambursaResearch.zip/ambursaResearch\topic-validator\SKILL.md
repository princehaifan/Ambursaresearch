---
name: topic-validator
description: >
  Step 1 of 6 in the ambursaResearch Pipeline. Validates your research topic
  against the existing literature using the Convergence Method. Identifies a
  real gap, confirms the question is publishable, and rules out dead ends
  before you write a single word. This is where first papers are won or lost.
  Saves as topic_brief.md.
---

# Topic Validator

Most researchers spend months on a paper that was never going to work.
Not because they were not smart enough.
Because they never validated the topic first.
They picked a question that felt important,
assumed a gap existed,
and found out at peer review that it had already been answered.
This step exists to prevent that.
Before you write a word,
before you design a method,
before you decide on a journal —
you will validate the topic.
You will confirm the gap is real.
You will confirm the question is answerable with what you have.
You will confirm a journal wants this paper.
Only then do you proceed.
Save as `topic_brief.md`.

---

## The Convergence Method

```
THE CONVERGENCE METHOD: HOW FASTTRACK VALIDATES A TOPIC

A research topic is valid when THREE things converge:

  AXIS 1: YOUR EXPERTISE AND INTEREST
    What do you know deeply?
    What problem keeps you awake because it is unsolved?
    What dataset, clinical access, or domain knowledge do you have
    that most researchers in this area do not?

  AXIS 2: A REAL GAP IN THE LITERATURE
    What has NOT been studied yet?
    What has been studied but only in one population?
    What finding is contested in the literature (conflicting results)?
    What method has never been applied to this problem?
    What time period or context has never been covered?

  AXIS 3: WHAT JOURNALS WANT RIGHT NOW
    What is trending in this field?
    What calls for papers exist?
    What journals have published papers close to — but not exactly — yours?
    What would a reviewer in this journal say is missing from their field?

  THE CONVERGENCE RULE:
  Your topic is valid when all three axes overlap.
  Strong on two, weak on one = not yet.
  Wait. Adjust. Find the overlap.
```

---

## Step 1 — The Topic Generation Interview

```
ASK THESE QUESTIONS IN ORDER. DO NOT SKIP.

ABOUT YOUR BACKGROUND:
  → What is your field or sub-field?
  → What is your current role (PhD student, clinician, early-career researcher,
    practitioner, etc.)?
  → Do you have access to any data, patient populations, or unique observations
    that others in your field do not?
  → What is the problem in your field that frustrates you most?
  → Have you read any papers recently that felt incomplete or wrong?

ABOUT YOUR CONSTRAINTS:
  → How many hours per week can you commit to this paper? (Be honest.)
  → Do you have a deadline (thesis, grant, job application)?
  → Do you have a supervisor, collaborators, or institutional requirements?
  → What methods can you actually do? (Systematic review, survey, secondary
    data analysis, lab work, qualitative interviews, modelling, etc.)

ABOUT THE TOPIC ITSELF:
  → What is the topic you are considering? (Describe it in one sentence.)
  → Why do you think this has not been done before?
  → What would you need to show to prove your hypothesis?
  → Who would care if you published this?
```

---

## Step 2 — The Duplication Test

```
BEFORE PROCEEDING, RUN THE DUPLICATION TEST.

THE TEST:
  Search your proposed question in:
  → PubMed / MEDLINE
  → Google Scholar
  → Cochrane (for systematic reviews)
  → The literature MCP tool (if available)

  Search for papers published in the last 5 years that answer
  your exact question.

  RESULT OPTIONS:

  OPTION A — No papers found:
    Good. But check: is there a reason no one has done this?
    Data unavailability? Ethical barriers? Genuinely unexplored?
    If the gap is real, proceed.

  OPTION B — Similar papers found, but not exactly yours:
    Good. These papers are your foundation.
    What is different about your question?
    Different population? Different outcome? Different method?
    Define the gap precisely. That gap IS your paper.

  OPTION C — Your exact question already answered:
    Stop. Do not proceed with this question.
    But do not give up. These papers have limitations sections.
    Read them. The authors tell you exactly what they could not do.
    That is your gap.

  OPTION D — Your exact question answered, recently, in a high-impact journal:
    This topic is exhausted for now.
    Return to Step 1 and find a new convergence.
```

---

## Step 3 — The Gap Statement

```
THE GAP STATEMENT IS THE MOST IMPORTANT SENTENCE YOU WILL WRITE.

STRUCTURE:
  "While previous research has established [what is known],
   no study has yet examined [what is unknown]
   in [specific population/context/time period],
   which matters because [consequence of the gap]."

EXAMPLES:

  WEAK (too vague):
  "Not much is known about the relationship between sleep and health."

  STRONG:
  "While systematic reviews have established associations between
   short sleep duration and cardiovascular risk in Western populations,
   no study has examined this relationship among shift workers in
   sub-Saharan African healthcare settings, where overnight shift patterns
   differ substantially and cardiovascular risk factors are understudied."

  WEAK (gap not meaningful):
  "No one has studied X in my city."

  STRONG:
  "While intervention studies on [X] have been conducted in high-income
   settings, the absence of evidence from low-resource contexts means
   that guidelines currently applied globally are based on evidence
   that may not generalise."

YOUR GAP STATEMENT MUST ANSWER:
  → What do we know? (3–5 papers minimum)
  → What do we NOT know? (the gap)
  → Why does the gap matter? (consequence for science or practice)
  → Why can YOU close it? (your unique position)
```

---

## Step 4 — The Publishability Test

```
FOUR QUESTIONS. ALL FOUR MUST PASS.

  TEST 1: NOVELTY
  Has this exact question been answered, in this population, with this method?
  If yes: not novel enough. Find the gap.
  If no: proceed.

  TEST 2: FEASIBILITY
  Can you actually do this study with the time, data, and methods you have?
  If the method requires 500 participants and you have access to 40: not feasible.
  Adjust scope, not ambition.

  TEST 3: SIGNIFICANCE
  Would a reader of a good journal in this field say: "I'm glad someone did this"?
  If the answer is shrug: the significance is not clear yet.
  Reframe.

  TEST 4: JOURNAL FIT
  Can you name 2–3 journals that have published papers in this exact space
  in the last 3 years?
  If no: either the space doesn't exist in the literature yet (too early),
  or you are looking in the wrong journals.
  Search harder before concluding it's too early.

  PASS ALL FOUR: proceed to literature-reviewer.
  FAIL ONE: identify which test failed and fix it before proceeding.
  FAIL TWO OR MORE: return to Step 1.
```

---

## Step 5 — The Journal Shortlist

```
BEFORE WRITING, KNOW WHERE YOU ARE WRITING FOR.

BUILD A JOURNAL SHORTLIST OF 3–5 JOURNALS:

  FOR EACH JOURNAL, RECORD:
  → Journal name
  → Impact factor (approximate)
  → Typical time from submission to first decision
  → Open access or subscription?
  → Article types accepted (original research, review, case study, etc.)
  → Recent papers in your area (2–3 examples)
  → Why this journal fits your paper

  THE TARGETING RULE:
  Aim for the highest journal you have evidence your paper could reach.
  Not the highest journal you have heard of.
  Evidence = recent papers in your area, in that journal.

  THE SCOPING RULE:
  Write the methods and results to match the journal you are targeting.
  A methods section for a clinical journal looks different from
  a methods section for a social science journal.
  Know your target before you write.
```

---

## Output File: topic_brief.md

```markdown
# Topic Brief
Pipeline step: 1 of 6 — ambursaResearch
Date: [date]

---

## Researcher Profile
Field: [field]
Role: [PhD student / clinician / researcher / practitioner]
Unique access: [what you have that others do not]
Hours per week: [X]
Hard deadline: [date or none]
Methods available: [list]

---

## Research Question
One-sentence topic: [write it]
Gap statement:
  "While [what is known], no study has yet examined [what is unknown]
   in [population/context], which matters because [consequence]."

---

## Duplication Test Result
Closest papers found: [list 3–5 with authors, year, journal]
Result: CLEAR / CLOSE (gap defined) / DUPLICATE (pivot required)
Gap defined as: [one sentence]

---

## Publishability Test
Novelty:     PASS / FAIL — [reason]
Feasibility: PASS / FAIL — [reason]
Significance: PASS / FAIL — [reason]
Journal fit: PASS / FAIL — [reason]
Overall: PROCEED / PIVOT

---

## Journal Shortlist
1. [Journal name] — IF [X] — [why it fits]
2. [Journal name] — IF [X] — [why it fits]
3. [Journal name] — IF [X] — [why it fits]
Primary target: [journal]

---

## Pipeline Status
Step 1 ✅ topic-validator    → topic_brief.md
Step 2 ⬜ lit-reviewer       → literature_map.md
Step 3 ⬜ method-architect   → study_design.md
Step 4 ⬜ paper-writer       → draft_sections.md
Step 5 ⬜ revision-engine    → revision_log.md
Step 6 ⬜ submission-ready   → submission_package.md
```

---

## Review Gate (MANDATORY)

After saving `topic_brief.md`, present this EXACTLY:

```
✅ Topic validated. Saved to topic_brief.md.

📋 Topic Summary:
- Research question: [one sentence]
- Gap: [one sentence]
- Publishability: [PASS / PIVOT — reason]
- Primary target journal: [journal name]

👉 You can:
  - Approve → say "approved" or "move to literature review"
  - Pivot the topic → say "pivot: [new direction]"
  - Narrow the scope → say "narrow: [what to cut]"
  - Change target journal → say "target: [journal name]"

⏸️ Waiting for approval before Literature Reviewer runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `move to literature review`, `lit review`,
`proceed`, `next`, `go`, `topic confirmed`, `start the review`
